﻿using System;

class NamePrint
{
    static void Main()
    {
        Console.WriteLine("Georgi");
    }
}

