﻿using System;

class CurentDateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}

